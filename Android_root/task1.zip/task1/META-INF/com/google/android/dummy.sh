echo hello > /system/testfile
